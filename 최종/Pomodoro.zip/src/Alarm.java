import java.awt.BorderLayout;


import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.Color;

public class Alarm extends JDialog {

	private final JPanel AlarmP = new JPanel();

	
	public Alarm() {
		
		JDialog Alarm = new JDialog();
		Alarm.setBackground(Color.WHITE);
		Alarm.setIconImage(Toolkit.getDefaultToolkit().getImage(Alarm.class.getResource("/image/KakaoTalk_20180504_233750108.gif")));
		Alarm.setTitle("Alarm");
		
		Alarm.setBounds(600, 400, 450, 218);
		Alarm.getContentPane().setLayout(new BorderLayout());
		AlarmP.setBackground(new Color(255, 250, 250));
		AlarmP.setBorder(new EmptyBorder(5, 5, 5, 5));
		Alarm.getContentPane().add(AlarmP, BorderLayout.CENTER);
		AlarmP.setLayout(null);
		
		JLabel label = new JLabel();
		label.setFont(new Font("a����", Font.PLAIN, 17));
		label.setBounds(50, 67, 297, 18);
		AlarmP.add(label);
		if(New.ALARMMUSIC == null) {
			label.setText("������ �˶����� �����ϴ�.");
		}else {
			String a = New.ALARMMUSIC;
			int lastIndex;
			if(a.contains("/")) {
				lastIndex = a.lastIndexOf("/");
			}else {
				lastIndex = a.lastIndexOf("\\");
			}
			label.setText(a.substring(lastIndex+1));
		}
		
		Alarm.setVisible(true);
	}

}
