
import javax.swing.DefaultListModel;
import javax.swing.JLabel;

public class Timer extends Thread{
	
	private JLabel myLabel = null;
	public static int studying = 0;
	public static int round = 0;
	public static int studyMinute;
	public static int studySecond;
	private int play = 0;
	private DefaultListModel<String> playList = New.LIST;
	
	static Music m = null;
	
	Timer(){
		
	}
	
	Timer(JLabel myLabel){
		this.myLabel = myLabel;
	}
	
	public void run(){
		Frame.STATE.setText("������");
		
		String a = playList.get(play);
		playList.addElement(a);
		play++;
		m = new Music(a, true);
		m.start();
		
		for(studyMinute=24; studyMinute>=0; studyMinute--) {
			for(studySecond=59; studySecond>=0; studySecond--) {
				try {
					Thread.sleep(1000);
				}catch(InterruptedException ex) {
			
				}
				myLabel.setText(studyMinute + " : " + studySecond);
			}
		}
		m.close();
		if(studying < 3) {
			studying++;
			rest();
		}else {
			fullRest();
		}
	}
	
	public void rest() {
		Music p = new Music(New.ALARMMUSIC, false);
		p.start();
		Frame.STATE.setText("�޽���");
		for(int i=4; i>=0; i--) {
			for(int j=59; j>=0; j--) {
				myLabel.setText(i + " : " + j);
				try {
					Thread.sleep(1000);
				}catch(InterruptedException ex) {
			
				}
			}
		}
		Music p2 = new Music(New.ALARMMUSIC, false);
		p2.start();
		run();
	}
	
	public void fullRest() {
		Music p = new Music(New.ALARMMUSIC, false);
		p.start();
		Frame.STATE.setText("�޽���");
		for(int i=29; i>=0; i--) {
			for(int j=59; j>=0; j--) {
				myLabel.setText(i + " : " + j);
				try {
					Thread.sleep(1000);
				}catch(InterruptedException ex) {
			
				}
			}
		}
		studying = 0;
		round++;
		Music p2 = new Music(New.ALARMMUSIC, false);
		p2.start();
		run();
	}
	
	public static String totalHour() {
		int totalSecond, second, hour = 0, minute;
		totalSecond = 100 * 60 * round + 25 * 60 * studying + (24-studyMinute)*60 + (60-studySecond);
		second = totalSecond%60;
		while(totalSecond/60 >= 60) {
			hour++;
			totalSecond -= 60;
		}
		minute = totalSecond/60;
		String totalHour = Integer.toString(hour) + " : " +  Integer.toString(minute) + " : " + Integer.toString(second); 
		
		return totalHour;
	}
}
