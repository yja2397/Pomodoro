import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

public class New extends JFrame implements ActionListener{

	private JPanel NewP;
	private JTextField goal_textField;

	private JFileChooser jfc = new JFileChooser();
	
	private JFrame New;
	private JButton Play;
	private JButton Alarm_bring;
	private JButton WhiteBGM_save;
	private JButton WhiteBGM_bring;
	private JButton Start;
	private JComboBox Alarm_comboBox;
	private String path;
	private JLabel Bringed_WhiteBGM_label;
	private JLabel Bringed_Alarm_label;
	private DefaultListModel<String> list = new DefaultListModel<String>();
	private DefaultListModel<String> list2 = new DefaultListModel<String>();
	private JList<String> WhiteBGM_list = new JList<>(list2);
	private JComboBox WhiteBGM_comboBox;
	private String AlarmMusic;
	private String getPath;
	
	public static String TITLE = null;
	public static String ALARMMUSIC = null;
	public static DefaultListModel<String> LIST;
	
	public New() {
		
		New = new JFrame();
		
		New.setBackground(Color.WHITE);
		New.setIconImage(Toolkit.getDefaultToolkit().getImage(New.class.getResource("/image/KakaoTalk_20180504_233750108.gif")));
		New.setTitle("New");
		New.setBounds(600, 250, 435, 495);
		NewP = new JPanel();
		NewP.setBackground(new Color(255, 250, 250));
		NewP.setBorder(new EmptyBorder(5, 5, 5, 5));
		New.setContentPane(NewP);
		NewP.setLayout(null);
		
		// ��ǥ
		JLabel goal = new JLabel("��ǥ : ");
		goal.setFont(new Font("a����", Font.PLAIN, 15));
		goal.setBounds(56, 29, 62, 18);
		NewP.add(goal);
		
		goal_textField = new JTextField();
		goal_textField.setBounds(111, 26, 243, 24);
		NewP.add(goal_textField);
		goal_textField.setColumns(10);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(0, 142, 432, 2);
		NewP.add(separator);
		
		// �˶���
		JLabel Alarm_label = new JLabel("�˸���");
		Alarm_label.setFont(new Font("a����", Font.PLAIN, 15));
		Alarm_label.setBounds(56, 73, 62, 18);
		NewP.add(Alarm_label);
		
		Bringed_Alarm_label = new JLabel(""); // �ٸ� ���� �����ϰ� �Ǹ� ������ �˶����� �������� �˷��ִ� ���.
		Bringed_Alarm_label.setForeground(Color.RED);
		Bringed_Alarm_label.setFont(new Font("a����", Font.PLAIN, 15));
		Bringed_Alarm_label.setBounds(121, 73, 258, 18);
		NewP.add(Bringed_Alarm_label);
		
		String[] alarm = new String[]{"Alarm1", "Alarm2", "Alarm3", "Alarm4", "Bells1", "Bells2", "Birds", "Christmas", "Cuckoo", "Electricity", "Flute", "FluteNotification", "Guitar", "Jingle", "MusicBox", "Phone", "SleighBells", "TwinkleBells", "Xylophone"};
		
		Alarm_comboBox = new JComboBox(alarm);
		Alarm_comboBox.setBounds(56, 103, 224, 24);
		NewP.add(Alarm_comboBox);
		
		Play = new JButton("���");
		Play.setFont(new Font("a����", Font.PLAIN, 13));
		Play.setBounds(294, 100, 59, 30);
		Play.addActionListener(this);
		NewP.add(Play);
		
		jfc.setFileFilter(new FileNameExtensionFilter("mp3", "mp3"));
		jfc.setMultiSelectionEnabled(false);
		
		Alarm_bring = new JButton("...");
		Alarm_bring.setBounds(359, 100, 38, 30);
		Alarm_bring.addActionListener(this);
		NewP.add(Alarm_bring);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(0, 59, 432, 2);
		NewP.add(separator_1);
		
		// �������
		JLabel WhiteBGM = new JLabel("�������");
		WhiteBGM.setFont(new Font("a����", Font.PLAIN, 15));
		WhiteBGM.setBounds(56, 156, 62, 18);
		NewP.add(WhiteBGM);
		
		Bringed_WhiteBGM_label = new JLabel("");
		Bringed_WhiteBGM_label.setForeground(Color.RED);
		Bringed_WhiteBGM_label.setFont(new Font("a����", Font.PLAIN, 15));
		Bringed_WhiteBGM_label.setBounds(121, 156, 258, 18);
		NewP.add(Bringed_WhiteBGM_label);
		
		String[] music = {"������", "��ȭ�ο� �ó�", "ȣ������ ������", "���� ����", "����� �� ī��", "�ƴ��� ����", "���� ���Ҹ�", "��Ʈ ����� �Ҹ�"};
		
		WhiteBGM_comboBox = new JComboBox(music);
		WhiteBGM_comboBox.setBounds(56, 186, 224, 24);
		NewP.add(WhiteBGM_comboBox);
		
		WhiteBGM_save = new JButton("�ֱ�");
		WhiteBGM_save.setFont(new Font("a����", Font.PLAIN, 13));
		WhiteBGM_save.setBounds(295, 184, 59, 30);
		WhiteBGM_save.addActionListener(this);
		NewP.add(WhiteBGM_save);
		
		WhiteBGM_bring = new JButton("...");
		WhiteBGM_bring.setBounds(359, 183, 38, 30);
		WhiteBGM_bring.addActionListener(this);
		NewP.add(WhiteBGM_bring);
		
		JPanel WhiteBGM_panel = new JPanel();
		WhiteBGM_panel.setBounds(56, 228, 297, 158);
		WhiteBGM_panel.setLayout(new BorderLayout(0,0));
		NewP.add(WhiteBGM_panel);
		
		WhiteBGM_list.setBounds(0, 0, 297, 158);
		WhiteBGM_list.setBorder(new LineBorder(new Color(0, 0, 0)));
		WhiteBGM_list.setFont(new Font("a����", Font.PLAIN, 15));
		WhiteBGM_panel.add(new JScrollPane(WhiteBGM_list), "Center");
		
		Start = new JButton("���� �� ����");
		Start.setFont(new Font("a����", Font.PLAIN, 15));
		Start.setBounds(280, 398, 117, 27);
		Start.addActionListener(this);
		NewP.add(Start);
		
		New.setVisible(true);
	}
	
	public void setPath(String path) {
		this.path = path;
	}
	public String getPath() {
		return path;
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		if(arg0.getSource() == Play){
			
			
			if(arg0.getSource().equals(Alarm_comboBox)) {
				JComboBox cb = (JComboBox) arg0.getSource();
				AlarmMusic = (String) cb.getSelectedItem();
			}else {
				AlarmMusic = Alarm_comboBox.getSelectedItem().toString();
			}
			AlarmMusic = selectMusic(AlarmMusic);
			Music p = new Music(AlarmMusic, false);
			p.start();
			
		}else if(arg0.getSource() == Alarm_bring) {
			Bringed_Alarm_label.setText("");
			if(jfc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
				setPath(jfc.getSelectedFile().toString());
				Bringed_Alarm_label.setText(getPath());
			}
		}else if(arg0.getSource() == WhiteBGM_bring) {
			Bringed_WhiteBGM_label.setText("");
			if(jfc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
				setPath(jfc.getSelectedFile().toString());
				getPath = getPath();
				String a = getPath();
				int lastIndex = a.lastIndexOf("\\");
				Bringed_WhiteBGM_label.setText(a.substring(lastIndex+1));
			}
		}else if(arg0.getSource() == WhiteBGM_save) {
			if(Bringed_WhiteBGM_label.getText() != "") {
				list.addElement(getPath);
				list2.addElement(Bringed_WhiteBGM_label.getText());
				Bringed_WhiteBGM_label.setText("");
			}else {
				String WhiteBGM_Music;
				if(arg0.getSource().equals(WhiteBGM_comboBox)) {
					JComboBox cb = (JComboBox) arg0.getSource();
					WhiteBGM_Music = (String) cb.getSelectedItem();
				}else {
					WhiteBGM_Music = WhiteBGM_comboBox.getSelectedItem().toString();
				}
				list.addElement(selectMusic(WhiteBGM_Music));
				list2.addElement(WhiteBGM_Music);
			}
		}else if(arg0.getSource() == Start){
			
			TITLE = goal_textField.getText();
			Frame.GOAL.setText(TITLE);
			
			if(arg0.getSource().equals(Alarm_comboBox)) {
				JComboBox cb = (JComboBox) arg0.getSource();
				AlarmMusic = (String) cb.getSelectedItem();
			}else {
				AlarmMusic = Alarm_comboBox.getSelectedItem().toString();
			}
			ALARMMUSIC = selectMusic(AlarmMusic);
			
			if(list.size() == 0) {
				list.addElement(selectMusic("���� ���Ҹ�"));
			}
			LIST = list;
			
			New.dispose();
			
			(new Timer(Frame.TIMER)).start();
			
		}else {
			System.out.println("wrong!");
		}
	}
	
	public String selectMusic(String Name) {
		String Music;
		String path;
		path = New.class.getResource("").getPath();
		Music = path + "/Music/" + Name + ".mp3";
		return Music;
	}
}
