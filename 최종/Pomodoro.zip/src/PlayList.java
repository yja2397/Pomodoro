import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;

import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

public class PlayList extends JFrame {

	private JPanel PlayListP;

	PlayList() {
		JFrame PlayList = new JFrame("PlayList");
		PlayList.setBackground(Color.WHITE);
		PlayList.setBounds(600, 400, 450, 300);
		PlayListP = new JPanel();
		PlayListP.setBackground(new Color(255, 250, 250));
		PlayListP.setBorder(new EmptyBorder(5, 5, 5, 5));
		PlayList.setContentPane(PlayListP);
		PlayListP.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(64, 41, 297, 158);
		panel.setLayout(new BorderLayout(0,0));
		PlayListP.add(panel);
		
		JList list = new JList();
		list.setFont(new Font("a����", Font.PLAIN, 15));
		list.setBorder(new LineBorder(new Color(0, 0, 0)));
		list.setBounds(0, 0, 600, 158);

		DefaultListModel<String> playList= new DefaultListModel<String>();
		
		if(New.LIST == null) {
			playList.addElement("���� ����ǰ� �ִ� ������ �����ϴ�.");
		}else {
			for(int i = 0; i < New.LIST.size(); i++) {
				String a = New.LIST.getElementAt(i);
				int lastIndex;
				if(a.contains("/")) {
					lastIndex = a.lastIndexOf("/");
				}else {
					lastIndex = a.lastIndexOf("\\");
				}
				playList.addElement(a.substring(lastIndex+1));
			}
		}
		list.setModel(playList);
		
		panel.add(new JScrollPane(list), "Center");
		
		PlayList.setVisible(true);
	}
}
