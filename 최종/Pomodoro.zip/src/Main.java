import java.sql.SQLException;

public class Main extends Thread{
	public static void main(String args[]) throws SQLException{
		new Frame();
	}
}
