import java.awt.Color;
import java.awt.Font;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.TrayIcon.MessageType;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;

public class Frame{

	private JPanel FrameP;
	
	public static JLabel GOAL;
	public static JLabel STATE;
	public static JLabel TIMER;
	
	public Frame() {
		
		JFrame frame = new JFrame();
		
		frame.setForeground(Color.LIGHT_GRAY);
		frame.setTitle("Pomato");
		frame.setFont(new Font("a����", Font.PLAIN, 12));
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage(Frame.class.getResource("/image/KakaoTalk_20180504_233750108.gif")));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(550, 300, 720, 446);
		FrameP = new JPanel();
		FrameP.setBorder(new EmptyBorder(5, 5, 5, 5));
		frame.setContentPane(FrameP);
		FrameP.setLayout(null);
		
		GOAL = new JLabel();
		GOAL.setHorizontalAlignment(JLabel.CENTER);
		GOAL.setFont(new Font("a����", Font.PLAIN, 30));
		GOAL.setBounds(152, 227, 402, 36);
		GOAL.setText("�н���ǥ");
		FrameP.add(GOAL);
		
		STATE = new JLabel("�غ���");
		STATE.setFont(new Font("a����", Font.PLAIN, 52));
		STATE.setBounds(285, 122, 123, 68);
		FrameP.add(STATE);
		
		JLabel Pharse = new JLabel("���� �� ���� ���Ϸ� �̷��� ����");
		Pharse.setFont(new Font("a����", Font.PLAIN, 20));
		Pharse.setBounds(60, 66, 262, 36);
		EtchedBorder eborder = new EtchedBorder(EtchedBorder.RAISED);
		Pharse.setBorder(eborder);
		FrameP.add(Pharse);
		
		TIMER = new JLabel("25 : 00");
		TIMER.setHorizontalAlignment(JLabel.CENTER);
		TIMER.setFont(new Font("a����", Font.PLAIN, 30));
		TIMER.setBounds(285, 308, 135, 36);
		FrameP.add(TIMER);
		
		JButton Start_button = new JButton("");
		Start_button.setIcon(new ImageIcon(Frame.class.getResource("/image/KakaoTalk_20180507_165208597.png")));
		Start_button.setBackground(SystemColor.menu);
		Start_button.setBounds(555, 296, 48, 48);
		Start_button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new New();
			}
		});
		FrameP.add(Start_button);
		
		
		// menu bar
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBackground(new Color(255, 228, 225));
		menuBar.setForeground(new Color(255, 255, 255));
		menuBar.setBounds(0, 0, 700, 26);
		FrameP.add(menuBar);
		
		
		// Home
		JMenu mnHome = new JMenu("Home");
		mnHome.setFont(new Font("a����", Font.PLAIN, 15));
		menuBar.add(mnHome);
		
		JMenuItem mntmNew = new JMenuItem("New");
		mntmNew.setFont(new Font("�����ձ۾� ��", Font.PLAIN, 20));
		mntmNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new New();
			}
		});
		mnHome.add(mntmNew);
		
		JMenuItem mntmShow = new JMenuItem("Show");
		mntmShow.setFont(new Font("�����ձ۾� ��", Font.PLAIN, 20));
		mntmShow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new ShowStudy();
			}
		});
		mnHome.add(mntmShow);
		
		JMenuItem mntmSave = new JMenuItem("Save");
		mntmSave.setFont(new Font("�����ձ۾� ��", Font.PLAIN, 20));
		mntmSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				SaveData s = new SaveData();
				s.dataSave();
				System.exit(0);
			}
		});
		mnHome.add(mntmSave);
		
		
		// Sound
		JMenu mnSound = new JMenu("Sound");
		mnSound.setFont(new Font("a����", Font.PLAIN, 15));
		menuBar.add(mnSound);
		
		JMenuItem mntmPlayList = new JMenuItem("��� ���");
		mntmPlayList.setFont(new Font("�����ձ۾� ��", Font.PLAIN, 20));
		mntmPlayList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new PlayList();
			}
		});
		mnSound.add(mntmPlayList);
		
		
		JMenuItem mntmPause = new JMenuItem("����");
		mntmPause.setFont(new Font("�����ձ۾� ��", Font.PLAIN, 20));
		mntmPause.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Timer.m.close();
			}
		});
		mnSound.add(mntmPause);
		
		JMenuItem mntmAlarm = new JMenuItem("�˶���");
		mntmAlarm.setFont(new Font("�����ձ۾� ��", Font.PLAIN, 20));
		mntmAlarm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new Alarm();
			}
		});
		mnSound.add(mntmAlarm);
	
		JLabel Background = new JLabel("");
		Background.setIcon(new ImageIcon(Frame.class.getResource("/image/background.jpg")));
		Background.setBounds(0, 0, 700, 400);
		FrameP.add(Background);
		
		TrayIcon2.registerTrayIcon(Toolkit.getDefaultToolkit().getImage("src/image/Tomato.png"), "Pomato",
				new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
			}
		});

		TrayIcon2.displayMessage("Pomato", "������ �����սô�!", MessageType.INFO);
		
		TrayIcon2.addItem("Close Window", 
				new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JDialog f = new JDialog();
				GraphicsDevice screenSize = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
				int width = screenSize.getDisplayMode().getWidth();
				int height = screenSize.getDisplayMode().getHeight();
				f.getContentPane().setBackground(Color.black);
				f.setBounds(0, 0, width+4, height);
				f.setVisible(true);
			}
		});
		
		TrayIcon2.addItem("Music Stop", new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Timer.m.close();
			}
		});
		
		TrayIcon2.addItem("Exit", 
				new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				SaveData s = new SaveData();
				s.dataSave();
				System.exit(0);
			}
		});
		

		frame.setVisible(true);
		
	}
	
	
}
