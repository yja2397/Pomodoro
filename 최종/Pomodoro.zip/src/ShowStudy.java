import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

public class ShowStudy {
	
	private JPanel ShowListP;
	
	ShowStudy(){
		JFrame ShowList = new JFrame("�н����");
		ShowList.setBackground(Color.WHITE);
		ShowList.setBounds(600, 400, 750, 300);
		ShowListP = new JPanel();
		ShowListP.setBackground(new Color(255, 250, 250));
		ShowListP.setBorder(new EmptyBorder(5, 5, 5, 5));
		ShowList.setContentPane(ShowListP);
		ShowListP.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(64, 41, 600, 158);
		panel.setLayout(new BorderLayout(0,0));
		ShowListP.add(panel);
		
		SaveData s = new SaveData();
		
		ArrayList<String> s2 = s.getList();
		
		String[] s3 = new String[s2.size()];
		for(int i = 0; i < s3.length; i++) {
			s3[i] = s2.get(i);
		}
		
		JList list = new JList(s3);
		list.setFont(new Font("a����", Font.PLAIN, 15));
		list.setBorder(new LineBorder(new Color(0, 0, 0)));
		list.setBounds(0, 0, 297, 158);
		
		panel.add(new JScrollPane(list), "Center");
		
		ShowList.setVisible(true);
	}
}
